#include <iostream>
#include <queue>
using namespace std;
class Stack
{
public:
queue<int> que1;
queue<int> que2;

    void push(int element)
    {
        que2.push(element);
        while(!que1.empty())
        {
            que2.push(que1.front());
            que1.pop();
        }
        queue<int> que3 = que1;//swapping
        que1=que2;
        que2=que3;
    }
    void pop()
    {
        if(que1.empty())
        {
            return;
        }
        else
        {
            que1.pop();
        }
    }
    int top()
    {
        if(que1.empty())
        {
            return -1;
        }
        else
        {
            return que1.front();
        }
    }
    void Display()
    {
        queue<int> que3 = que1;
        while(!que3.empty())
        {
            cout<<que3.front()<<" ";
             que3.pop();
        }
        cout<<endl;
    }
};

int main()
{
    Stack s1;
    int element;
    int choice;
    do
    {
        cout<<"Welcome to FCI StackUsingQueues"<<endl;
        cout<<"---------------------------------------------------"<<endl;
        cout<<"1-Push\n";
        cout<<"2-Pop\n";
        cout<<"3-Top\n";
        cout<<"4-Print\n";
        cout<<"5-EXIT\n";
        cout<<"ENTER YOUR CHOICE : ";
        cin>>choice;
        switch(choice)
        {
        case 1:
            {
                cout<<"ENTER THE ELEMENT THAT YOU WANT TO PUSH : ";
                cin>>element;
                s1.push(element);
                break;
            }
        case 2:
            {
                s1.pop();
                break;
            }
        case 3:
            {
                cout<<"THE TOP IS: "<<s1.top()<<endl;
                break;
            }
        case 4:
            {
                s1.Display();
                break;
            }
        case 5:
            {
                cout<<"GOODBYE"<<endl;
                break;
            }
        default:
            {
                cout<<"INVALID CHOICE,PLEASE ENTER AGAIN"<<endl;
                break;
            }
        }
    }while(choice!=5);

    return 0;
}


